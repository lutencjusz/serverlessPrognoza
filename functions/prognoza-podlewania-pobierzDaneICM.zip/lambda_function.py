import json
import urllib.request
import boto3
import os
from datetime import datetime

sqs = boto3.client('sqs')

def send_sqs(komunikat): #wysyła komunikat do kolejki
    try:
        sqs.send_message(
            QueueUrl=os.environ['SQS_URL'],
            MessageBody=json.dumps(komunikat)
        )  
    except Exception as err:
        print ("Nie udało się wysłać komunikatu do kolejki Airly: {}", err)

def intStrAdd0(liczba):
    if liczba<10:
        return '0'+str(liczba)
    else:
        return str(liczba)

def lambda_handler(event, context):
    
    date_format = "%Y-%m-%dT%H:%M:%SZ"
    teraz = datetime.now()
    terazICMStr = str(teraz.year)+'-'+intStrAdd0(teraz.month)+'-'+intStrAdd0(teraz.day)+'T00'#+str(teraz.hour)
    # url = 'https://api.meteo.pl:443/api/v1/model/wrf/grid/d02_XLONG_XLAT/coordinates/284,386/field/T2/level/0/date/2020-02-24T00/forecast/'
    url = 'https://api.meteo.pl:443/api/v1/model/wrf/grid/d02_XLONG_XLAT/coordinates/284,386/field/T2/level/0/date/'+terazICMStr+'/forecast/'
    print('URL: ', url)
    
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
    newConditions = {} # jest potrzebne, żeby urllib.request.Request przełączyć z GET na POST
    params = json.dumps(newConditions).encode('utf8')
    apikey = os.environ['apikey']
    headers = {
        'Authorization': 'Token {}'.format(apikey),
        'User-Agent': user_agent,
        'Accept': 'application/json'
    }
    licznik = 0
    wynikTablica = []
    req = urllib.request.Request(url, data=params, headers = headers)
    try:
        with urllib.request.urlopen(req) as x:
            res = json.loads(x.read().decode('utf-8'))
            for i in range(len(res['times'])):
                data = datetime.strptime(res['times'][i], date_format)
                waga = round((2/((data - teraz).total_seconds()/60/60)), 6)
                if waga<0:
                    waga = 0 - waga
                
                if waga>2:
                    waga = 2

                # Jezeli stopnie cencjusz 'C', to przelicza temper
                t = res['data'][i]
                if os.environ['jednostka'] == 'C' and t > 200:
                    t = round(t - 272.15, 2)

                komunikat = {
                    'timestamp': str(teraz),
                    'data': str(data),
                    'temp': t,
                    'waga': waga,
                    'tabela': 'pognozaICM'
                }
                #print(str(komunikat))
                wynikTablica.append(komunikat)
                licznik +=1
                
        send_sqs(wynikTablica)            
        print ('Wysłano {} komunikatów.' .format(licznik))
    except Exception as err:
        print('Nie udało się poło się pobrać danych: {}' .format(err))
   
    return 'OK' 
