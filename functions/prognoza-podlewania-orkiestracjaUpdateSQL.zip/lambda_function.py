import json
import sys
import os
import boto3
client = boto3.client('stepfunctions')

def lambda_handler(event, context):

    for record in event['Records']:
        recordObj = json.loads(record['body'])
        try:
            if  recordObj['id'] != None:
                client.start_execution(
                    stateMachineArn=os.environ['STEPFUNCTION_ARN'],
                    input=json.dumps(recordObj)
                )
            else:
                print('Brak parametru id jest None')    
                
        except:
            print('Brak parametru id')

    return 'OK'
    