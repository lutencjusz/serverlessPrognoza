import json
import sys
import pymysql
import os

rds_host = os.environ['db_endpoint']
name = os.environ['db_username']
password = os.environ['password']
db_name = os.environ['db_name']
port = 3306

class Blad( Exception ): pass

def lambda_komunikat(event):
    
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        return {
            "status": 401,
            "comment": "error during MySQL loading!"
            }

    kolumny = ['timestamp', 'waga', 'temp_odcz', 'naglowek', 'komentarz', 'zachmurzenie', 'opis', 'predkosc_wiatru', 'temp', 'data',
    'cisnienie', 'uruchomic', 'id', 'wilgotnosc', 'dataUtworzenia', 'PM1', 'PM10', 'PM25', 'PRESSURE', 'HUMIDITY', 'TEMPERATURE',
    'AIRQUALITYADVICE', 'COLORCODE', 'LEVEL', 'TEMPERATURE_ICM', 'cZP_temp', 'cZP_temp_odcz', 'uv', 'widocznosc', 'pora_dnia', 'opady', 'opady_prawd',
    'temp_weatherbit', 'temp_odcz_weatherbit', 'cisnienie_weatherbit', 'opis_weatherbit', 'uv_weatherbit', 'widocznosc_weatherbit', 'pora_dnia_weatherbit', 
    'opady_weatherbit', 'opady_prawd_weatherbit', 'predkosc_wiatru_weatherbit', 'zachmurzenie_weatherbit', 'wilgotnosc_weatherbit', 'cZP_temp_weatherbit', 'cZP_temp_odcz_weatherbit']
    
    wart=[]
    tK=[] #musi być osobno, bo wtedy powstają osobne tablice
    
    for k in kolumny:
        try:
            if event[k] == None:
                print ('Wartosc kolumny {} jest None' .format(k))
            else:
                wart.append(event[k])
                tK.append(k)
        except:
            print ('Nie znaleziono kolumny: {}' .format(k))

    sql = 'insert into '+str(event['tabela'])+' ('+str(tK).replace("'", "").replace("[","").replace("]","")+') values ('+str(wart).replace("[","").replace("]","").replace("Decimal('","").replace("')","")+')'

    print ('sql= ', sql)

    with conn.cursor() as cur:
        try:
            cur.execute(sql)
            conn.commit()
        except Exception as err:
            raise Blad('Blad {}' .format(err))

    return 'OK'
    

def lambda_handler(event, context):
    
    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat(i)
            wynik.append(w)
            
        return wynik
    else:
        event = lambda_komunikat(event)
        return event
    
    return 'Blad'
