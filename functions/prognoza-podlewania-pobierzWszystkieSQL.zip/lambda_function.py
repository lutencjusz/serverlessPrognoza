import json
import sys
import pymysql
import os
import boto3
from decimal import Decimal
from datetime import datetime

sqs = boto3.client('sqs')
date_format = "%Y-%m-%d %H:%M:%S"

def default(obj):
    if isinstance(obj, Decimal):
        return float(obj) #konwertuje decimal na float (json)
    if isinstance(obj, datetime):
        return str(datetime.strptime(str(obj), date_format))
    raise TypeError("Object of type '%s' is not JSON serializable" % type(obj).__name__)

def send_sqs(komunikat): #wysyła komunikat do kolejki
    try:
        sqs.send_message(
            QueueUrl=os.environ['SQS_URL'],
            MessageBody=json.dumps(komunikat, default=default)
        )  
    except Exception as err:
        print ("Nie udało się wysłać komunikatu do kolejki Update: ", err)

rds_host = os.environ['rds_host']
name = os.environ['db_username']
password = os.environ['password']
db_name = os.environ['db_name']
port = 3306

def lambda_handler(event, context):
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        return {
            "status": 401,
            "comment": "error during MySQL loading!"
            }

    tabela = os.environ['db_table']
    licznik = 0
    wynikTablica = []
    
    with conn.cursor() as cur:
        cur.execute('select '+os.environ['fields']+' from '+str(tabela)+' where cZP_temp is null and waga = 2 order by data desc limit '+os.environ['limit'])
        row_headers=[x[0] for x in cur.description] #this will extract row headers
        records = cur.fetchall()
        conn.commit()
        conn.close()
        
        for result in records:
            wynik = dict(zip(row_headers,result))
            wynik['tabela']=tabela
            wynikTablica.append(wynik)
            licznik += 1
    
    send_sqs(wynikTablica) #wysłano komunkat do kolejki update        
    print ('Wysłano komunkatów: ', licznik)
    return 'OK'        

