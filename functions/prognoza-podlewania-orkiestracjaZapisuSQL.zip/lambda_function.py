import json
import sys
import os
import boto3
client = boto3.client('stepfunctions')

def lambda_handler(event, context):

    for record in event['Records']:
        recordObj = json.loads(record['body'])
        try:
            recordObj['temp'] = round(recordObj['temp']-272.15,2)
        except:
            print('Brak parametru temp')

        client.start_execution(
            stateMachineArn=os.environ['STEPFUNCTION_ARN'],
            input=json.dumps(recordObj)
        )

    return 'OK'
    