import json
import urllib.request
import boto3
import os

sqs = boto3.client('sqs')

def send_sqs(komunikat): #wysyła komunikat do kolejki
    try:
        sqs.send_message(
            QueueUrl=os.environ['SQS_URL'],
            MessageBody=json.dumps(komunikat)
        )  
    except Exception as err:
        print ("Nie udało się wysłać komunikatu do kolejki Airly: {}", err)

def przeliczTemp(t):
    if os.environ['jednostka'] == 'C':
        return round(t - 272.15, 2)
    else:
        return t
        
    return 'Blad'

def lambda_handler(event, context):
    url = 'https://api.openweathermap.org/data/2.5/forecast?q=Warsaw,pl&APPID='+os.environ['apikey']
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
    values = {'name': 'lutencjusz','location': 'Poland','language': 'Python' }
    headers = {'User-Agent': user_agent, 'Accept': 'application/json'}
    
    licznik = 0
    tablicaKomunikatow = []
    req = urllib.request.Request(url,headers = headers)
    with urllib.request.urlopen(req) as x:
        res = json.loads(x.read().decode('utf-8'))
        for i in res['list']:
            row = {}
            row['data'] = i['dt_txt']
            row['temp'] = przeliczTemp(i['main']['temp'])
            row['temp_odcz'] = przeliczTemp(i['main']['feels_like'])
            row['cisnienie'] = i['main']['pressure']
            row['wilgotnosc'] = i['main']['humidity']
            row['opis'] = i['weather'][0]['description']
            row['zachmurzenie'] = i['clouds']['all']
            row['predkosc_wiatru'] = i['wind']['speed']
            row['tabela'] = 'prognozaPodlewaniaDB'
            row['licznik'] = licznik
            licznik += 1
            tablicaKomunikatow.append(row)
            if licznik > int(os.environ['max']):
                send_sqs(tablicaKomunikatow)
                print ('Ilość wysłanych komunikatów prognozy: ', licznik)
                licznik = 0
                tablicaKomunikatow = []

    send_sqs(tablicaKomunikatow)
    print ('Ilość wysłanych komunikatów prognozy: ', licznik)
    return tablicaKomunikatow
