import boto3

tr = boto3.client('translate')

class Blad( Exception ): pass

def lambda_komunikat(event):
    responseOpis = tr.translate_text(
        Text= event['opis'],
        SourceLanguageCode= 'en',
        TargetLanguageCode= 'pl'
    )
    event['opis'] = responseOpis['TranslatedText']

    try:
        responseAirlyAdvice = tr.translate_text(
            Text= event['AIRQUALITYADVICE'],
            SourceLanguageCode= 'en',
            TargetLanguageCode= 'pl'
        )
        event['AIRQUALITYADVICE'] = responseAirlyAdvice['TranslatedText']
    except:
        print('Brak tłumaczenia AirlyAdvice')
    
    try:
        responseWeatherbit = tr.translate_text(
            Text= event['opis_weatherbit'],
            SourceLanguageCode= 'en',
            TargetLanguageCode= 'pl'
        )
        event['opis_weatherbit'] = responseWeatherbit['TranslatedText']
    except:
        print('Brak tłumaczenia opisWeatherbit')

    
    event['komentarz'] = event['komentarz'] + responseOpis['TranslatedText'] + '; '
    
    return event     

def lambda_handler(event, context):
    
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return Blad('Blad {}' .format(err))