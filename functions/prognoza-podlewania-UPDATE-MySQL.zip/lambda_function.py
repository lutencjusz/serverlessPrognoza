import json
import sys
import pymysql
import os


rds_host = os.environ['rds_host']
name = os.environ['db_username']
password = os.environ['password']
db_name = os.environ['db_name']
port = 3306

class Blad( Exception ): pass

def lambda_handler(event, context):
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        return {
            "status": 401,
            "comment": "error during MySQL loading!"
            }

    tabela = event['tabela']
    licznik = 0
    
    kolumny = os.environ['field_update'].split(', ')
    
    wart=''
    tK=[] #musi być osobno, bo wtedy powstają osobne tablice
    
    for k in kolumny:
        try:
            if event[k] == None:
                print ('Wartosc kolumny {} jest None' .format(k))
            else:
                wart += ', '+str(k)+' = '+str(event[k])
        except:
            print ('Nie znaleziono kolumny: {}' .format(k))
    
    wart = wart[2:]
    sql = 'update '+str(event['tabela'])+' set '+wart+" where id = '"+str(event['id']+"'")
    
    try:
        with conn.cursor() as cur:
            cur.execute(sql)
            conn.commit()
            conn.close()
            print ('sql: ', sql)
    except Exception as err:
        raise Blad('Blad {}' .format(err))

    return 'OK'        
