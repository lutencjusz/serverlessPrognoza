import json
import sys
import pymysql
import os

rds_host = os.environ['rds_host']
name = os.environ['db_username']
password = os.environ['password']
db_name = os.environ['db_name']
port = 3306

class Blad( Exception ): pass

def lambda_komunikat (event):
    if event['waga'] >= 2:
        try:
            conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
        except:
            return {
                "status": 401,
                "comment": "error during MySQL loading!"
                }
    
        sql = "SELECT MIN(temp), MAX(temp), MIN(temp_odcz), MAX(temp_odcz), MIN(temp_weatherbit), MAX(temp_weatherbit), MIN(temp_odcz_weatherbit), MAX(temp_odcz_weatherbit) FROM prognozaPodlewaniaDB WHERE data='" +event['data']+ "' AND waga < 2 GROUP BY data"
    
        print ('sql= ', sql)
    
        with conn.cursor() as cur:
            try:
                temp = event['temp']
                temp_odcz = event['temp_odcz']
                temp_weatherbit = event['temp_weatherbit']
                temp_odcz_weatherbit = event['temp_odcz_weatherbit']
                cur.execute(sql)
                records = cur.fetchall()
                for row in records:
                    # print('Min:', row[0])
                    # print('Max:', row[1])
                    # print('wartosc', temp)
                    
                    if temp <= row[1] and temp >= row[0]:
                        event['cZP_temp'] = True
                    else:
                        event['cZP_temp'] = False
                    
                    #print('Min_odcz:', row[0])
                    #print('Max_odcz:', row[1])
                    #print('temp ', temp)
                        
                    if temp_weatherbit <= row[5] and temp_weatherbit >= row[4]:
                        event['cZP_temp_weatherbit'] = True
                    else:
                        event['cZP_temp_weatherbit'] = False
                        
                    #print('Min_odcz:', row[4])
                    #print('Max_odcz:', row[5])
                    #print('temp_weatherbit ', temp_weatherbit)
                    
                    if temp_odcz <= row[3] and temp_odcz >= row[2]:
                        event['cZP_temp_odcz'] = True
                    else:
                        event['cZP_temp_odcz'] = False
                        
                    if temp_odcz_weatherbit <= row[7] and temp_odcz_weatherbit >= row[6]:
                        event['cZP_temp_odcz_weatherbit'] = True
                    else:
                        event['cZP_temp_odcz_weatherbit'] = False
                    
                    #print('Min:', row[6])
                    #print('Max:', row[7])
                    #print('temp_odcz_weatherbit ', temp_odcz_weatherbit)
                    
                # conn.commit()
                # event['TEMPERATURE_ICM']=cur.fetchone()[0]
            except Exception as err:
                print ('Blad: {}' .format(err))

    return event    
    
def lambda_handler(event, context):
    
    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return Blad('Blad {}' .format(err))