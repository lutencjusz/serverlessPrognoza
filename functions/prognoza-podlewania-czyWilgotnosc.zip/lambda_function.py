import json
import os
class Blad( Exception ): pass

def lambda_komunikat(event):
    jp = event
    print (jp['komentarz'])
    
    # Zabezpieczenie przed brakiem parametru
    try:
        jp['komentarz']
    except KeyError:
        jp['komentarz'] = ""
    try:
        jp['uruchomic']
    except KeyError:
        jp['uruchomic'] = True

    if float(jp['wilgotnosc']) > float(os.environ['max']) and float(jp['zachmurzenie']) > float(os.environ['minZachmurzenie']):
        jp['naglowek'] = "Będzie padać!"
        jp['komentarz'] = jp['komentarz'] + "wilgotnosc (" + str(jp['wilgotnosc']) + ") > Max(" + os.environ['max'] + ") i chmury(" + str(jp['zachmurzenie']) + ") > Max (" + str(os.environ['minZachmurzenie']) + "); "
        jp['uruchomic'] = False
    elif float(jp['wilgotnosc']) > float(os.environ['opt']) and float(jp['zachmurzenie']) > float(os.environ['minZachmurzenie']):
        jp['naglowek'] = "Wilgotnosc wieksza od optymalnej!"
        jp['komentarz'] = jp['komentarz'] + "wilgotnosc (" + str(jp['wilgotnosc']) + ") > Opt(" + os.environ['opt'] + ") i chmury(" + str(jp['zachmurzenie']) + ") > Max (" + str(os.environ['minZachmurzenie']) + "). Jest deszczowo, nie warto podlewac; "
        jp['uruchomic'] = False
        
    if float(jp['wilgotnosc']) < float(os.environ['min']):
        jp['naglowek'] = "Zbyt niska wilgotnosc, pomiar niewairygodny - nie podlewam!"
        jp['komentarz'] = jp['komentarz'] + "wilgotnosc (" + str(jp['wilgotnosc']) + ") < Min(" + os.environ['min'] + "); "
        jp['uruchomic'] = False
    
    return jp

def lambda_handler(event, context):

    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return Blad('Blad {}' .format(err))

