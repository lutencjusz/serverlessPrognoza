import json
import uuid
from datetime import datetime, timedelta
from dateutil.parser import parse

def lambda_komunikat (event):
    
    date_format = "%Y-%m-%d %H:%M:%S"
    try:
        dt = datetime.strptime(event['data'], date_format)
    except:
        date_format_airly = "%Y-%m-%dT%H:%M:%S.%f"
        dt = datetime.strptime(event['data'][:-1], date_format_airly)

    now = datetime.now()
    newnow = datetime.strptime(str(datetime(now.year, now.month, now.day, now.hour)), date_format)
    #print('nowy czas: ',str(newnow))
    
    #generuje id rekordku do 
    event['id'] = str(uuid.uuid4());
    event['dataUtworzenia'] = str(now)

    
    if dt.minute != 0 or dt.second !=0:
        event['waga'] = 2;
        event['data'] = str(newnow)
    else:    
        event['waga'] = round((2/((dt - now).total_seconds()/60/60)), 6)
        
    if event['waga'] > 2 or event['waga'] < -2:
        event['waga'] = 1.99

    if event['waga'] < 0 and event['waga'] >= -2:
        event['waga'] = 0 - event['waga']
    

    return event    

def lambda_handler(event, context):

    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return 'blad'

