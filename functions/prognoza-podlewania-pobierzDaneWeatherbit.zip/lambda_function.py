import json
import urllib.request
import boto3
import os
from datetime import datetime

sqs = boto3.client('sqs')

def send_sqs(komunikat): #wysyła komunikat do kolejki
    try:
        sqs.send_message(
            QueueUrl=os.environ['SQS_URL'],
            MessageBody=json.dumps(komunikat)
        )  
    except Exception as err:
        print ("Nie udało się wysłać komunikatu do kolejki Airly: {}", err)

def intStrAdd0(liczba):
    if liczba<10:
        return '0'+str(liczba)
    else:
        return str(liczba)

def lambda_handler(event, context):

    date_format = "%Y-%m-%dT%H:%M:%S"
    teraz = datetime.now()
    
    url = 'https://weatherbit-v1-mashape.p.rapidapi.com/forecast/hourly?lang=en&lat=52.243554&lon=20.961445&hours=120'
    print('URL: ', url)
    
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
    #newConditions = {} # jest potrzebne, żeby urllib.request.Request przełączyć z GET na POST
    #params = json.dumps(newConditions).encode('utf8')
    apikey = os.environ['apikey']
    headers = {
        'x-rapidapi-key': apikey,
        'x-rapidapi-host': 'weatherbit-v1-mashape.p.rapidapi.com',
        'Accept': 'application/json'
    }
    licznik = 1
    wynikTablica = []
    poraDnia = 0
    req = urllib.request.Request(url, headers = headers)
    print(str(req))
    
    try:
        with urllib.request.urlopen(req) as x:
            res = json.loads(x.read().decode('utf-8'))
            for i in range(len(res['data'])):
                data = datetime.strptime(res['data'][i]['timestamp_utc'], date_format)

                # konwersja pory dnia
                if res['data'][i]['pod'] == 'n':
                    poraDnia = 1
                else:
                    poraDnia = 0

                komunikat = {
                    'timestamp': str(teraz),
                    'data': str(data),
                    'temp': res['data'][i]['temp'],
                    'tabela': 'prognozaWeatherbit',
                    'cisnienie': res['data'][i]['pres'],
                    'opis': res['data'][i]['weather']['description'],
                    'temp_odcz': res['data'][i]['app_temp'],
                    'uv': res['data'][i]['uv'],
                    'widocznosc': res['data'][i]['vis'],
                    'pora_dnia': poraDnia,
                    'opady': res['data'][i]['precip'],
                    'opady_prawd': res['data'][i]['pop'],
                    'predkosc_wiatru': res['data'][i]['wind_spd'],
                    'zachmurzenie': res['data'][i]['clouds'],
                    'wilgotnosc': res['data'][i]['rh']
                }
                #print(str(komunikat))
                wynikTablica.append(komunikat)
                licznik +=1
                if licznik > 40:
                    licznik = 0
                    send_sqs(wynikTablica)
                    wynikTablica = []
                
        send_sqs(wynikTablica)            
        print ('Wysłano {} komunikatów.' .format(licznik))
    except Exception as err:
        print('Nie udało się poło się pobrać danych: {}' .format(err))

    return 'OK'
