const https = require('https');
const aws = require('aws-sdk');

const sqs = new aws.SQS({apiVersion: '2012-11-05'});

//let url = "https://api.openweathermap.org/data/2.5/forecast?q=Warsaw,pl&APPID=6e4f748efd51cdf7bdc15e6c9710fda8";
let url = "https://api.openweathermap.org/data/2.5/weather?q=Warsaw,pl&APPID=6e4f748efd51cdf7bdc15e6c9710fda8";

const queue_url = 'https://sqs.eu-west-1.amazonaws.com/790651879093/prognozaPogody'
let licznik = 0;

exports.handler =  function(event, context, callback) {
    https.get(url, (resp) => {
        let data = '';
        let res={};

        resp.on('data', (chunk) => {
            data += chunk;
        });

        resp.on('end', () => {
            const wynik = JSON.parse(data);
            //console.log(wynik);
            
            //let dt = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '')

            res = {
                data: new Date().toISOString().replace(/T/, ' ').replace(/\..+/, ''),
                temp: wynik['main']['temp'],
                temp_odcz: wynik['main']['feels_like'],
                cisnienie: wynik['main']['pressure'],
                wilgotnosc: wynik['main']['humidity'],
                opis: wynik['weather'][0]['description'],
                zachmurzenie: wynik['clouds']['all'],
                predkosc_wiatru: wynik['wind']['speed'],
                tabela: 'prognozaPodlewaniaDB',
                licznik: licznik
            };
                console.log(res);
                
                const params = {
                  MessageBody: JSON.stringify(res),
                  QueueUrl: queue_url
                };
                sqs.sendMessage(params, function(err, data) {
                  if (err) {
                    console.log("Error", err);
                  } else {
                    licznik += 1;
                    console.log("Success", licznik.toString());
                  }
                });
            callback(null, 'OK');
        });
    
    }).on("error", (err) => {
        callback(null, 'Blad: '+err);
    });
};