import json
import os
class Blad( Exception ): pass

def lambda_komunikat(jp):

    try:
        jp['komentarz']
    except KeyError:
        jp['komentarz'] = ""
    try:
        jp['uruchomic']
    except KeyError:
        jp['uruchomic'] = True

    # Jezeli stopnie cencjusz 'C', to przelicza temper
    if os.environ['jednostka'] == 'C' and jp['temp'] > 200:
        jp['temp'] = round(jp['temp'] - 272.15, 2)
        jp['temp_odcz'] = round(jp['temp_odcz'] - 272.15, 2)
    
    # Jezeli sprawdzamy po temperaturze odczuwalnej, to odpowiednio ustawiam zmienną temp
    temp = jp['temp']
    if os.environ['rodzajTemp'] == 'odczuwalna':
        temp = jp['temp_odcz']
    
    if float(temp) > float(os.environ['max']):
        jp['naglowek'] = "Temperatura za wysoka!"
        jp['komentarz'] = jp['komentarz'] + "Temperatura (" + str(temp) + ") > Max(" + os.environ['max'] + "); "
        jp['uruchomic'] = False

    if float(temp) < float(os.environ['min']):
        jp['naglowek'] = "Temperatura zbyt niska!"
        jp['komentarz'] = jp['komentarz'] + "Temperatura (" + str(temp) + ") < Min(" + os.environ['min'] + "); "
        jp['uruchomic'] = False

    return jp
    
def lambda_handler(event, context):
    jp = json.loads(event)
    #print(type(event))
    if isinstance(jp, list):
        wynik = []
        for i in jp:
            w = lambda_komunikat(i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat(jp)
        return event
    
    return Blad('Blad {}' .format(err))
