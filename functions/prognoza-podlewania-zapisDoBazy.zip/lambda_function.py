import boto3
import json
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
class Blad( Exception ): pass

def lambda_komunikat(event):
    # konwertuje float na decimal
    jp = json.loads(json.dumps(event), parse_float=Decimal)

    #Zapisuje w bazie
    table = dynamodb.Table(os.environ['DB_NAME'])
    table.put_item(
        Item=jp
    )
    
    return "OK"  

def lambda_handler(event, context):
    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return Blad('Blad {}' .format(err))
