import json
import os
from datetime import datetime, timedelta
class Blad( Exception ): pass

def lambda_komunikat(event):

    # Zabezpieczenie przed brakiem parametru
    try:
        event['komentarz']
    except KeyError:
        event['komentarz'] = ""
    try:
        event['uruchomic']
    except KeyError:
        event['uruchomic'] = True
    # core funkcji
    
    date_format = "%Y-%m-%d %H:%M:%S"
    try:
        dt = datetime.strptime(event['data'], date_format)
    except:
        date_format_airly = "%Y-%m-%dT%H:%M:%S.%f"
        dt = datetime.strptime(event['data'][:-1], date_format_airly)

    if dt.weekday() == 5 or dt.weekday() == 6:
        lista = os.environ['godzinyWeekend'].split(', ')
    else:
        lista = os.environ['godzinyTydzien'].split(', ')

    if event['komentarz'] == '':
        event['komentarz'] += ', '
        
    if str(dt.hour) in lista:
        event['komentarz'] += 'pora na rower; '
    else:
        event['uruchomic'] = False
        event['komentarz'] += 'to nie jest pora na rower; '
    
    return event

def lambda_handler(event, context):

    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return Blad('Blad {}' .format(err))

