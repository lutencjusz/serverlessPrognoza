import json
import urllib.request
import boto3
import os
from datetime import datetime, timedelta

sqs = boto3.client('sqs')

def send_sqs(komunikat): #wysyła komunikat do kolejki
    try:
        sqs.send_message(
            QueueUrl=os.environ['SQS_URL'],
            MessageBody=json.dumps(komunikat)
        )  
    except Exception as err:
        print ("Nie udało się wysłać komunikatu do kolejki Airly: {}", err)

def intStrAdd0(liczba):
    if liczba<10:
        return '0'+str(liczba)
    else:
        return str(liczba)

def lambda_handler(event, context):
    
    date_format = "%Y-%m-%dT%H:%M:%SZ"
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
    newConditions = {} # jest potrzebne, żeby urllib.request.Request przełączyć z GET na POST
    params = json.dumps(newConditions).encode('utf8')
    apikey = os.environ['apikey']
    headers = {
        'Authorization': 'Token {}'.format(apikey),
        'User-Agent': user_agent,
        'Accept': 'application/json'
    }
    godzinyPobierania=[0, 6, 12, 18]
    iloscDni = 38;
    dataPoczatkowa = datetime(2020, 1, 16, 0)
    godzina = timedelta(hours=1)
    dzien = timedelta(days=1)
    sekunda = timedelta(seconds=1)
    licznik = 0

    for ilDni in range(iloscDni):
        for ilGodz in godzinyPobierania:
            teraz = dataPoczatkowa+(ilDni*dzien)+(ilGodz*godzina)
            terazICMStr = str(teraz.year)+'-'+intStrAdd0(teraz.month)+'-'+intStrAdd0(teraz.day)+'T'+intStrAdd0(teraz.hour)
            url = 'https://api.meteo.pl:443/api/v1/model/wrf/grid/d02_XLONG_XLAT/coordinates/284,386/field/T2/level/0/date/'+terazICMStr+'/forecast/'
            print(url)
            
            try:
                req = urllib.request.Request(url, data=params, headers = headers)
                with urllib.request.urlopen(req) as x:
                    res = json.loads(x.read().decode('utf-8'))
                    for i in range(len(res['times'])):
                        data = datetime.strptime(res['times'][i], date_format)

                        if (data - teraz) == 0:
                            waga = 2
                        else:
                            waga = round((2/((data - (teraz+sekunda)).total_seconds()/60/60)), 6)
                        
                        if waga<0:
                            waga = 0 - waga
                        
                        if waga>2:
                            waga = 2
                        
                        komunikat = {
                            'timestamp': str(teraz),
                            'data': str(data),
                            'temp': res['data'][i],
                            'waga': waga
                        }
                        print(str(komunikat))
                        send_sqs(komunikat)
                        licznik +=1
                    
                print ('Wysłano {} komunikatów.' .format(licznik))
            except Exception as err:
                print('Nie udało się poło się pobrać danych: {}' .format(err))

    return 'OK'
