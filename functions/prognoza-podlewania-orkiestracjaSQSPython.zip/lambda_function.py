import json
import boto3
import os

client = boto3.client('stepfunctions')

def lambda_handler(event, context):
    for record in event['Records']:
        print("Pobralem z SQS: " + record['body'])

        client.start_execution(
            stateMachineArn=os.environ['STEPFUNCTION_ARN'],
            input=json.dumps(record['body']),
        )
    
    return 'OK'

