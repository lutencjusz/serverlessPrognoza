import json
import sys
import pymysql
import os
import boto3
from boto3.dynamodb.conditions import Key, Attr

rds_host = os.environ['db_endpoint']
name = os.environ['db_username']
password = os.environ['password']
db_name = os.environ['db_name']
port = 3306

dynamodb = boto3.resource('dynamodb')
id = '056ac89f-6127-4d11-b0f0-89a2d281e0b6'

def lambda_handler(event, context):
    item_count = 0
    itemError_count = 0
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        return {
            "status": 401,
            "comment": "error during MySQL loading!"
            }

    try:
        table = dynamodb.Table(os.environ['DYNAMODB_NAME'])
    except Exception as err:
        return 'Blad: '+str(err)

    #items = table.query(KeyConditionExpression=Key('id').eq(id))
    items = table.scan()

    for i in items['Items']:
        kolumny = ['waga', 'temp_odcz', 'naglowek', 'komentarz', 'zachmurzenie', 'opis', 'predkosc_wiatru', 'temp', 'data', 'cisnienie', 'uruchomic', 'id', 'wilgotnosc', 'dataUtworzenia', 'PM1', 'PM10', 'PM25', 'PRESSURE', 'HUMIDITY', 'TEMPERATURE', 'AIRQUALITYADVICE', 'COLORCODE', 'LEVEL', 'TEMPERATURE_ICM']
    
        wart=[]
        tK=[] #musi być osobno, bo wtedy powstają osobne tablice
    
        for k in kolumny:
            try:
                wart.append(i[k])
                tK.append(k)
            except:
                print ('Nie znaleziono kolumny: {}' .format(k))

        sql = 'insert into prognozaPodlewaniaDB ('+str(tK).replace("'", "").replace("[","").replace("]","")+') values ('+str(wart).replace("[","").replace("]","").replace("Decimal('","").replace("')","")+')'

        print ('sql= ', sql)
        with conn.cursor() as cur:
            # cur.execute("create table prognozaPodlewaniaDB (id varchar(255) PRIMARY KEY, naglowek varchar(255) NOT NULL, dataUtworzenia varchar(255), komentarz varchar(255), zachmurzenie varchar(255), opis varchar(255), data varchar(255), waga decimal(6,6), temp decimal(10,2), temp_odcz decimal(10,2), wilgotnosc int, predkosc_wiatru decimal(10,2), cisnienie int, uruchomic boolean)")
            # cur.execute("insert into tablica1 (waga, temp_odcz, naglowek, komentarz, zachmurzenie, opis, predkosc_wiatru, temp, data, cisnienie, uruchomic, id, wilgotnosc) values (0.437259, 2.29, 'Będzie padać!', 'Temperatura (2.29) < Min(10), wilgotnosc (54) > Max(50) i chmury(100) > Max (20)', 100, 'zachmurzone chmury', 8.9, 10.42, '2020-02-16 18:00:00', 1015, False, '0659c85c-76d2-4b4c-95a3-7raf78e8c51b', 54)")

            try:
                cur.execute(sql)
                conn.commit()
                item_count += 1
            except Exception as err:
                itemError_count += 1
                print ('Blad: {}' .format(err))

    return {
        "status": 200,
        "comment": "Writed "+str(item_count)+" / not writed "+str(itemError_count)+" items from DynamoDB to RDS MySQL table"
        }