import json
import sys
import pymysql
import os

rds_host = os.environ['rds_host']
name = os.environ['db_username']
password = os.environ['password']
db_name = os.environ['db_name']
port = 3306
class Blad( Exception ): pass

def lambda_komunikat(event):
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        return {
            "status": 401,
            "comment": "error during MySQL loading!"
            }

    sql = "SELECT PM1, PM25, PM10, PRESSURE, HUMIDITY, TEMPERATURE, AIRQUALITYADVICE, COLORCODE, LEVEL, waga FROM prognozaAirly WHERE data='" +event['data']+ "' ORDER BY waga DESC LIMIT 1"

    print ('sql= ', sql)

    with conn.cursor() as cur:
        try:
            cur.execute(sql)
            wynik = cur.fetchall()

            for x in wynik:
                event['PM1']=x[0]
                event['PM25']=x[1]
                event['PM10']=x[2]
                event['PRESSURE']=x[3]
                event['HUMIDITY']=x[4]
                event['TEMPERATURE']=x[5]
                event['AIRQUALITYADVICE']=x[6]
                event['COLORCODE']=x[7]
                event['LEVEL']=x[8]

        except Exception as err:
            print ('Blad: {}' .format(err))

    return event
    
def lambda_handler(event, context):
    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return Blad('Blad {}' .format(err))
