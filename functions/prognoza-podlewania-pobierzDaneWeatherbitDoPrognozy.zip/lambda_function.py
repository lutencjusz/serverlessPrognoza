import json
import sys
import pymysql
import os

rds_host = os.environ['rds_host']
name = os.environ['db_username']
password = os.environ['password']
db_name = os.environ['db_name']
port = 3306
class Blad( Exception ): pass

def lambda_komunikat(event):
    try:
        conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    except:
        return {
            "status": 401,
            "comment": "error during MySQL loading!"
            }

    sql = "SELECT temp, temp_odcz, cisnienie, opis, uv, widocznosc, pora_dnia, opady, opady_prawd, predkosc_wiatru, zachmurzenie, wilgotnosc, waga FROM prognozaWeatherbit WHERE data='" +event['data']+ "' ORDER BY waga DESC LIMIT 1"

    print ('sql: ', sql)

    with conn.cursor() as cur:
        try:
            cur.execute(sql)
            wynik = cur.fetchall()

            for x in wynik:
                event['temp_weatherbit']=x[0]
                event['temp_odcz_weatherbit']=x[1]
                event['cisnienie_weatherbit']=x[2]
                event['opis_weatherbit']=x[3]
                event['uv_weatherbit']=x[4]
                event['widocznosc_weatherbit']=x[5]
                event['pora_dnia_weatherbit']=x[6]
                event['opady_weatherbit']=x[7]
                event['opady_prawd_weatherbit']=x[8]
                event['predkosc_wiatru_weatherbit']=x[9]
                event['zachmurzenie_weatherbit']=x[10]
                event['wilgotnosc_weatherbit']=x[11]
                print ('waga: ', str(x[12]))

        except Exception as err:
            print ('Blad: {}' .format(err))

    return event
    
def lambda_handler(event, context):
    #print(type(event))
    if isinstance(event, list):
        wynik = []
        for i in event:
            w = lambda_komunikat (i)
            wynik.append(w)
        return wynik
    else:
        event = lambda_komunikat (event)
        return event
    
    return Blad('Blad {}' .format(err))
