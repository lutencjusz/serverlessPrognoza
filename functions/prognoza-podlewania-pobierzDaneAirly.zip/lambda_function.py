import json
import urllib.request
import boto3
import os

sqs = boto3.client('sqs')

def send_sqs(komunikat): #wysyła komunikat do kolejki
    try:
        sqs.send_message(
            QueueUrl=os.environ['SQS_URL'],
            MessageBody=json.dumps(komunikat)
        )  
    except Exception as err:
        print ("Nie udało się wysłać komunikatu do kolejki Airly: {}", err)

def fromMessToJson(nowykomunikat, wejciowyKomunikat, ti): #łączy dostępne jsony
    kj = wejciowyKomunikat

    for i in range(len(ti)): # Petla zapisuje wartosci dostepnych parametrow do wyjsciowej jsona
        for j in range(len(nowykomunikat)):
            a = nowykomunikat[j]['name']
            # print ('porownano: {}' .format(str(i)+' '+str(j)+' '+str(a)+' '+str(ti[i])))
            if str(a) == str(ti[i]):
                kj[ti[i]]=nowykomunikat[j]['value']
        
    return kj

def lambda_handler(event, context):

    url = 'https://airapi.airly.eu/v2/measurements/installation?installationId=6532'
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
    values = {'name': 'lutencjusz','location': 'Poland','language': 'Python' }
    headers = {'User-Agent': user_agent, 'Accept': 'application/json', 'apikey': os.environ['apikey']}
    
    licznik = 0

    req = urllib.request.Request(url,headers = headers)
    with urllib.request.urlopen(req) as x:
        res = json.loads(x.read().decode('utf-8'))
        event = fromMessToJson(res['current']['values'], event, ['PM1', 'PM25', 'PM10', 'PRESSURE', 'HUMIDITY', 'TEMPERATURE'])
        event['AIRQUALITYADVICE'] = res['current']['indexes'][0]['advice']
        event['COLORCODE'] = res['current']['indexes'][0]['color']
        event['LEVEL'] = res['current']['indexes'][0]['level']
        event['tabela'] = 'prognozaAirly'
        event['data'] = res['current']['fromDateTime']
        send_sqs(event)
 
    for i in res['forecast']:
        licznik +=1
        przyszlosc = {}
        przyszlosc['data'] = i['fromDateTime']
        przyszlosc['AIRQUALITYADVICE'] = i['indexes'][0]['advice']
        przyszlosc['COLORCODE'] = i['indexes'][0]['color']
        przyszlosc['LEVEL'] = i['indexes'][0]['level']
        przyszlosc['tabela'] = 'prognozaAirly'
        przyszlosc = fromMessToJson(i['values'], przyszlosc, ['PM25', 'PM10'])
        send_sqs(przyszlosc)
        # print ('wyslany komunikat: {}' .format(str(przyszlosc)))
            # print ('Komunikat: ', licznik)

    print ('Ilość wysłanych komunikatów prognozy: ', licznik)
    
    return event
